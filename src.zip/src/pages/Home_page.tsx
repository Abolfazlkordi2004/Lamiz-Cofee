import HomePage from "@/components/body";
import React from "react";

function Home_page() {
  return (
    <>
      <HomePage />
    </>
  );
}

export default Home_page;
