// import Header from "@/components/header";
// import NitroCold from "@/pages/product-category/nitro-cold-brew-coffee/page";

import Blowers from "@/pages/product-category/blowers/page";

export default function Home() {
  return (
    <>
      <Blowers />
    </>
  );
}
